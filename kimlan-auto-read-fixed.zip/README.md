# Bản sửa lỗi script Auto read

Lỗi cũ xảy ra khi giải nén trực tiếp bộ cài vào thư mục dự án, khiến file mẫu và file đích là cùng một đường dẫn.

Chạy:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\apply-auto-read.ps1 -ProjectRoot "C:\Users\Admin\Desktop\KimLan.group"
```

Script mới sẽ tự bỏ qua bước copy nếu file mẫu đã nằm đúng vị trí.
