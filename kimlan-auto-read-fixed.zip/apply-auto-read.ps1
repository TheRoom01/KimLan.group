param(
  [string]$ProjectRoot = "C:\Users\Admin\Desktop\KimLan.group"
)

$ErrorActionPreference = "Stop"

$roomModalPath = Join-Path $ProjectRoot "app\admin\RoomModal\index.tsx"
$autoReadPath = Join-Path $ProjectRoot "app\admin\RoomModal\AutoReadModal.tsx"
$templatePath = Join-Path $PSScriptRoot "app\admin\RoomModal\AutoReadModal.tsx"

if (!(Test-Path $roomModalPath)) {
  throw "Không tìm thấy file: $roomModalPath"
}

if (!(Test-Path $templatePath)) {
  throw "Không tìm thấy file mẫu: $templatePath"
}

New-Item -ItemType Directory -Force -Path (Split-Path $autoReadPath) | Out-Null

$resolvedTemplate = [System.IO.Path]::GetFullPath($templatePath)
$resolvedTarget = [System.IO.Path]::GetFullPath($autoReadPath)

if ($resolvedTemplate -ne $resolvedTarget) {
  Copy-Item -Force $templatePath $autoReadPath
} else {
  Write-Host "Bỏ qua copy AutoReadModal.tsx vì file mẫu đã nằm đúng vị trí đích." -ForegroundColor Yellow
}

$content = Get-Content -Raw -Encoding UTF8 $roomModalPath

function Replace-Once {
  param(
    [string]$InputText,
    [string]$OldText,
    [string]$NewText,
    [string]$Label
  )

  $index = $InputText.IndexOf($OldText)
  if ($index -lt 0) {
    throw "Không tìm thấy vị trí patch: $Label"
  }

  if ($InputText.IndexOf($OldText, $index + $OldText.Length) -ge 0) {
    throw "Có nhiều hơn 1 vị trí patch: $Label"
  }

  return $InputText.Substring(0, $index) + $NewText + $InputText.Substring($index + $OldText.Length)
}

if ($content -notmatch "AutoReadModal") {
  $content = Replace-Once $content `
    "import RoomAmenityTab from './RoomAmenityTab'" `
    @"
import RoomAmenityTab from './RoomAmenityTab'
import AutoReadModal, { type AutoReadCandidate } from './AutoReadModal'
"@ `
    "import AutoReadModal"
}

if ($content -notmatch "showAutoRead") {
  $content = Replace-Once $content `
    "const [showCloseConfirm, setShowCloseConfirm] = useState(false)" `
    @"
const [showCloseConfirm, setShowCloseConfirm] = useState(false)
const [showAutoRead, setShowAutoRead] = useState(false)
"@ `
    "state showAutoRead"
}

if ($content -notmatch "applyAutoReadCandidate") {
  $anchor = @"
const cancelCloseConfirm = () => {
  setShowCloseConfirm(false)
}
"@

  $replacement = @"
const cancelCloseConfirm = () => {
  setShowCloseConfirm(false)
}

const applyAutoReadCandidate = (
  candidate: AutoReadCandidate,
  shared: {
    room: Partial<RoomForm>
    detail: Partial<RoomDetail>
  }
) => {
  const nextRoom = { ...shared.room, ...candidate.room }
  const nextDetail = { ...shared.detail, ...candidate.detail }

  setRoomForm((prev) => ({
    ...prev,
    ...Object.fromEntries(
      Object.entries(nextRoom).filter(([, value]) => {
        if (typeof value === 'number') return Number.isFinite(value) && value > 0
        if (typeof value === 'boolean') return true
        return String(value ?? '').trim() !== ''
      })
    ),
    media: prev.media,
  } as RoomForm))

  setDetailForm((prev) => ({
    ...prev,
    ...Object.fromEntries(
      Object.entries(nextDetail).filter(([, value]) => {
        if (typeof value === 'number') return Number.isFinite(value) && value > 0
        if (typeof value === 'boolean') return true
        return String(value ?? '').trim() !== ''
      })
    ),
  } as RoomDetail))

  setFeeAutofillDone(true)
  setActiveTab('info')
  onNotify?.('✅ Auto read đã điền dữ liệu vào form. Vui lòng kiểm tra lại trước khi lưu.')
}
"@

  $content = Replace-Once $content $anchor $replacement "applyAutoReadCandidate"
}

if ($content -notmatch '>\s*Auto read\s*</button>') {
  $oldHeader = @"
          <h3>{isPending ? 'Chỉnh sửa import Zalo' : isEdit ? 'Chỉnh sửa phòng' : 'Thêm phòng mới'}</h3>
"@

  $newHeader = @"
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
            <h3 style={{ margin: 0 }}>
              {isPending ? 'Chỉnh sửa import Zalo' : isEdit ? 'Chỉnh sửa phòng' : 'Thêm phòng mới'}
            </h3>

            {!isPending && !isEdit && !isClone && (
              <button
                type="button"
                onClick={() => setShowAutoRead(true)}
                style={{
                  border: '1px solid #2563eb',
                  background: '#eff6ff',
                  color: '#1d4ed8',
                  padding: '9px 14px',
                  borderRadius: 10,
                  cursor: 'pointer',
                  fontWeight: 700,
                }}
              >
                Auto read
              </button>
            )}
          </div>
"@

  $content = Replace-Once $content $oldHeader $newHeader "nút Auto read"
}

if ($content -notmatch '<AutoReadModal') {
  $oldCloseConfirm = @"
      {showCloseConfirm && (
"@

  $newCloseConfirm = @"
      <AutoReadModal
        open={showAutoRead}
        onClose={() => setShowAutoRead(false)}
        onApply={applyAutoReadCandidate}
      />

      {showCloseConfirm && (
"@

  $content = Replace-Once $content $oldCloseConfirm $newCloseConfirm "render AutoReadModal"
}

Set-Content -Path $roomModalPath -Value $content -Encoding UTF8

Write-Host ""
Write-Host "Đã cập nhật:" -ForegroundColor Green
Write-Host "1. $autoReadPath"
Write-Host "2. $roomModalPath"
Write-Host ""
Write-Host "Chạy kiểm tra:" -ForegroundColor Cyan
Write-Host "cd `"$ProjectRoot`""
Write-Host "npm run build"
