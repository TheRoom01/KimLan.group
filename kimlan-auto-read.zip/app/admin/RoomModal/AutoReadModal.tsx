/* app/admin/RoomModal/AutoReadModal.tsx */
'use client'

import { useMemo, useState, type CSSProperties } from 'react'
import type { RoomDetail, RoomForm } from './types'

export type AutoReadCandidate = {
  room: Partial<RoomForm>
  detail: Partial<RoomDetail>
  warnings: string[]
  sourceText: string
}

export type AutoReadResult = {
  candidates: AutoReadCandidate[]
  sharedRoom: Partial<RoomForm>
  sharedDetail: Partial<RoomDetail>
  warnings: string[]
}

type Props = {
  open: boolean
  onClose: () => void
  onApply: (candidate: AutoReadCandidate, shared: {
    room: Partial<RoomForm>
    detail: Partial<RoomDetail>
  }) => void
}

const money = (raw?: string | null) => {
  if (!raw) return 0
  const s = raw.toLowerCase().replace(/\s+/g, '').replace(/,/g, '.')
  const million = s.match(/(\d+)(?:[.,](\d+))?\s*(?:tr|triệu|trieu)/i)
  if (million) {
    const whole = Number(million[1] || 0)
    const fractionRaw = million[2] || ''
    const fraction = fractionRaw ? Number(`0.${fractionRaw}`) : 0
    return Math.round((whole + fraction) * 1_000_000)
  }

  const compact = s.match(/(\d+)\s*tr\s*(\d{1,3})/i)
  if (compact) {
    const whole = Number(compact[1] || 0)
    const tail = String(compact[2] || '').padEnd(3, '0').slice(0, 3)
    return whole * 1_000_000 + Number(tail) * 1_000
  }

  const k = s.match(/(\d+(?:[.,]\d+)?)\s*k\b/i)
  if (k) return Math.round(Number(k[1].replace(',', '.')) * 1_000)

  const digits = s.replace(/[^\d]/g, '')
  return digits ? Number(digits) : 0
}

const normalizeText = (value: string) =>
  value
    .replace(/\r\n?/g, '\n')
    .replace(/\u00a0/g, ' ')
    .replace(/[ \t]+/g, ' ')
    .trim()

const stripAccent = (value: string) =>
  value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .toLowerCase()

const firstMatch = (text: string, regexes: RegExp[]) => {
  for (const re of regexes) {
    const m = text.match(re)
    if (m?.[1]) return m[1].trim()
  }
  return ''
}

function parseAddress(text: string): Partial<RoomForm> {
  const addressLine = firstMatch(text, [
    /(?:^|\n)\s*(?:📍|🏠|địa\s*chỉ|dia\s*chi|dc)\s*[:\-]\s*([^\n]+)/i,
    /(?:^|\n)\s*((?:\d+[a-zA-Z]?(?:\/\d+[a-zA-Z]?)*)\s+[^,\n]{3,}(?:,\s*(?:p(?:hường)?\.?\s*\d+|quận\s*\d+|q\.?\s*\d+)[^\n]*)?)/i,
  ])

  if (!addressLine) return {}

  const clean = addressLine.replace(/[📍🏠]/g, '').trim()
  const houseMatch = clean.match(/^(\d+[a-zA-Z]?(?:\/\d+[a-zA-Z]?)*)\s+(.+)$/)
  const house_number = houseMatch?.[1] || ''
  let rest = houseMatch?.[2] || clean

  const district = firstMatch(rest, [
    /(?:quận|q\.?)\s*([0-9]{1,2}|bình\s*thạnh|phú\s*nhuận|tân\s*bình|gò\s*vấp|bình\s*tân|tân\s*phú|thủ\s*đức)/i,
  ])
  const ward = firstMatch(rest, [
    /(?:phường|p\.?)\s*([0-9]{1,2}|[a-zà-ỹ\s]+?)(?=,|$)/i,
  ])

  rest = rest
    .replace(/,\s*(?:phường|p\.?)\s*[^,]+/i, '')
    .replace(/,\s*(?:quận|q\.?)\s*[^,]+/i, '')
    .trim()
    .replace(/,$/, '')

  return {
    house_number,
    address: rest,
    ward: ward ? (/^\d+$/.test(ward) ? `Phường ${ward}` : ward) : '',
    district: district
      ? (/^\d+$/.test(district) ? `Quận ${district}` : district.replace(/\b\w/g, c => c.toUpperCase()))
      : '',
  }
}

function inferRoomType(text: string) {
  const s = stripAccent(text)
  if (/\bduplex\b/.test(s)) return 'Duplex'
  if (/\bstudio\b/.test(s)) return 'Studio'
  if (/\b1\s*pn\b|\b1\s*phong ngu\b/.test(s)) return '1PN'
  if (/\b2\s*pn\b|\b2\s*phong ngu\b/.test(s)) return '2PN'
  if (/\b3\s*pn\b|\b3\s*phong ngu\b/.test(s)) return '3PN'
  if (/\bcan ho\b/.test(s)) return 'Căn hộ'
  if (/\bphong tro\b/.test(s)) return 'Phòng trọ'
  return ''
}

function extractRoomMarkers(text: string) {
  const lines = text.split('\n').map(x => x.trim()).filter(Boolean)
  const markers: Array<{ code: string; price: number; line: string }> = []
  const seen = new Set<string>()

  for (const line of lines) {
    const normalized = stripAccent(line)
    const hasPrice = /(?:\d+(?:[.,]\d+)?\s*(?:tr|trieu)|\d+\s*tr\s*\d{1,3}|\d[\d.,]{4,})/i.test(normalized)
    const codeMatches = [...line.matchAll(/\b(?:P|CH|A)?\s*(\d{2,4}|trệt|tret|lửng|lung)\b/gi)]

    if (!hasPrice || codeMatches.length === 0) continue
    if (/(?:điện|dien|nước|nuoc|phí|phi|cọc|coc|dịch vụ|dich vu)/i.test(normalized) &&
        !/(?:phòng|phong|trống|trong|giá|gia)/i.test(normalized)) continue

    const priceToken = firstMatch(line, [
      /(\d+\s*tr\s*\d{1,3})/i,
      /(\d+(?:[.,]\d+)?\s*(?:tr|triệu|trieu))/i,
      /(\d[\d.,]{4,})/,
    ])
    const price = money(priceToken)

    for (const m of codeMatches) {
      let code = String(m[0] || '').replace(/\s+/g, '').toUpperCase()
      if (/^\d+$/.test(code)) code = `P${code}`
      const key = `${code}|${price}`
      if (!seen.has(key)) {
        seen.add(key)
        markers.push({ code, price, line })
      }
    }
  }

  if (markers.length) return markers

  const labeledCode = firstMatch(text, [
    /(?:mã\s*phòng|ma\s*phong|phòng|phong)\s*[:\-]\s*([A-ZÀ-Ỹ0-9\-]+)/i,
  ])
  const labeledPrice = firstMatch(text, [
    /(?:giá\s*phòng|gia\s*phong|giá|gia)\s*[:\-]\s*([^\n]+)/i,
  ])
  if (labeledCode || labeledPrice) {
    return [{
      code: labeledCode.toUpperCase(),
      price: money(labeledPrice),
      line: [labeledCode, labeledPrice].filter(Boolean).join(' - '),
    }]
  }

  return []
}

function parseFees(text: string): Partial<RoomDetail> {
  const findValue = (label: string) => {
    const m = text.match(new RegExp(`(?:^|\\n)[^\\n]*${label}[^\\n]*?(\\d+(?:[.,]\\d+)?\\s*(?:k|tr|triệu|trieu)?)[^\\n]*`, 'i'))
    return money(m?.[1])
  }

  const electricLine = firstMatch(text, [/(?:điện|dien)\s*[:\-]?\s*([^\n]+)/i])
  const waterLine = firstMatch(text, [/(?:nước|nuoc)\s*[:\-]?\s*([^\n]+)/i])
  const serviceLine = firstMatch(text, [/(?:phí\s*(?:dịch\s*vụ)?|phi\s*(?:dich\s*vu)?)\s*[:\-]?\s*([^\n]+)/i])
  const parkingLine = firstMatch(text, [/(?:xe|gửi\s*xe|giu\s*xe|parking)\s*[:\-]?\s*([^\n]+)/i])

  return {
    electric_fee_value: money(electricLine),
    electric_fee_unit: /kwh|kw/i.test(electricLine) ? 'kWh' : 'kWh',
    water_fee_value: money(waterLine),
    water_fee_unit: /phòng|phong/i.test(waterLine) ? 'phòng/tháng' : 'người/tháng',
    service_fee_value: money(serviceLine),
    service_fee_unit: 'phòng/tháng',
    parking_fee_value: money(parkingLine),
    parking_fee_unit: 'chiếc',
  }
}

function parseAmenities(text: string): Partial<RoomDetail> {
  const s = stripAccent(text)
  const noPet = /\bkhong\s*(?:cho\s*)?(?:nuoi\s*)?(?:pet|cho|meo)\b|\bno\s*pet\b/.test(s)
  const allowCat = !noPet && /\b(?:cho\s*)?(?:nuoi\s*)?meo\b/.test(s)
  const allowDog = !noPet && /\b(?:cho\s*)?(?:nuoi\s*)?cho\b/.test(s)
  const allowPet = !noPet && (allowCat || allowDog || /\bpet\b|\bthu cung\b/.test(s))

  return {
    has_elevator: /\bthang may\b/.test(s),
    has_stairs: /\bthang bo\b|\bcau thang\b/.test(s),
    fingerprint_lock: /\bvan tay\b|\bkhoa van tay\b/.test(s),
    allow_pet: allowPet,
    allow_cat: allowCat,
    allow_dog: allowDog,
    no_pet: noPet,
    has_parking: /\bgiu xe\b|\bgui xe\b|\bde xe\b|\bparking\b/.test(s),
    has_basement: /\bham xe\b|\btang ham\b/.test(s),
    shared_washer: /\bmay giat chung\b|\bgiat chung\b/.test(s),
    private_washer: /\bmay giat rieng\b|\bgiat rieng\b/.test(s),
    shared_dryer: /\bmay say chung\b|\bsay chung\b/.test(s),
    private_dryer: /\bmay say rieng\b|\bsay rieng\b/.test(s),
    short_term: /\bngan han\b|\b3 thang\b|\b1 thang\b/.test(s),
    long_term: !/\bngan han\b/.test(s),
  }
}

function parsePolicies(text: string) {
  const lines = text.split('\n').map(x => x.trim()).filter(Boolean)
  return lines.filter(line => {
    const s = stripAccent(line)
    return /\bcoc\b|\bhop dong\b|\bcheck\s*in\b|\bvao o\b|\bchinh sach\b|\bbao truoc\b/.test(s)
  }).join('\n')
}

function parseDescription(text: string, markerLines: string[]) {
  const excluded = [
    /địa\s*chỉ|dia\s*chi|^\s*dc\s*:/i,
    /(?:điện|dien|nước|nuoc|phí|phi|cọc|coc|hợp đồng|hop dong|gửi xe|gui xe|giữ xe|giu xe)\s*[:\-]?/i,
    /(?:zalo|liên hệ|lien he|sđt|sdt|phone|hotline)/i,
  ]

  return text
    .split('\n')
    .map(x => x.trim())
    .filter(Boolean)
    .filter(line => !markerLines.includes(line))
    .filter(line => !excluded.some(re => re.test(line)))
    .join('\n')
}

export function parseAutoReadText(raw: string): AutoReadResult {
  const text = normalizeText(raw)
  const sharedRoom: Partial<RoomForm> = {
    ...parseAddress(text),
    room_type: inferRoomType(text),
    status: /đã\s*thuê|da\s*thue/i.test(stripAccent(text)) ? 'Đã thuê' : 'Trống',
    zalo_phone: firstMatch(text, [/(?:\+?84|0)(\d{9,10})\b/]).replace(/^(\d)/, '0$1'),
    link_zalo: firstMatch(text, [/(https?:\/\/(?:zalo\.me|chat\.zalo\.me)\/[^\s]+)/i]),
    chinh_sach: parsePolicies(text),
  }
  const sharedDetail: Partial<RoomDetail> = {
    ...parseFees(text),
    ...parseAmenities(text),
  }

  const markers = extractRoomMarkers(text)
  const markerLines = markers.map(x => x.line)
  const description = parseDescription(text, markerLines)

  if (!markers.length) {
    return {
      candidates: [{
        room: {
          ...sharedRoom,
          description,
        },
        detail: sharedDetail,
        warnings: ['Không tìm thấy mã phòng hoặc dòng giá rõ ràng. Hãy kiểm tra trước khi áp dụng.'],
        sourceText: text,
      }],
      sharedRoom,
      sharedDetail,
      warnings: ['NO_ROOM_MARKER'],
    }
  }

  return {
    candidates: markers.map(marker => ({
      room: {
        room_code: marker.code,
        price: marker.price,
        description,
      },
      detail: {},
      warnings: marker.price > 0 ? [] : ['Không nhận diện được giá phòng.'],
      sourceText: marker.line,
    })),
    sharedRoom,
    sharedDetail,
    warnings: markers.length > 1 ? [`Đã phát hiện ${markers.length} phòng. Hãy chọn đúng phòng.`] : [],
  }
}

const formatPrice = (value?: number) =>
  Number(value || 0).toLocaleString('vi-VN')

export default function AutoReadModal({ open, onClose, onApply }: Props) {
  const [rawText, setRawText] = useState('')
  const [result, setResult] = useState<AutoReadResult | null>(null)
  const [selected, setSelected] = useState(0)

  const selectedCandidate = useMemo(
    () => result?.candidates?.[selected] ?? null,
    [result, selected]
  )

  if (!open) return null

  const analyze = () => {
    const clean = rawText.trim()
    if (!clean) return
    const parsed = parseAutoReadText(clean)
    setResult(parsed)
    setSelected(0)
  }

  const apply = () => {
    if (!result || !selectedCandidate) return
    onApply(selectedCandidate, {
      room: result.sharedRoom,
      detail: result.sharedDetail,
    })
    onClose()
  }

  return (
    <div style={overlay} onPointerDown={e => e.stopPropagation()}>
      <div style={box} onPointerDown={e => e.stopPropagation()}>
        <div style={header}>
          <div>
            <div style={title}>Auto read</div>
            <div style={subTitle}>Dán nội dung tin nhắn để tự điền dữ liệu phòng.</div>
          </div>
          <button type="button" style={closeBtn} onClick={onClose}>×</button>
        </div>

        <textarea
          value={rawText}
          onChange={e => setRawText(e.target.value)}
          placeholder={'Ví dụ:\nĐịa chỉ: 90/88F Nguyễn Đình Chiểu, P.5, Quận 3\nP302 - 6tr5\nStudio, máy giặt riêng\nĐiện 4k, nước 100k/người'}
          style={textarea}
          autoFocus
        />

        <div style={actions}>
          <button type="button" style={secondaryBtn} onClick={() => {
            setRawText('')
            setResult(null)
            setSelected(0)
          }}>
            Xóa
          </button>
          <button type="button" style={analyzeBtn} disabled={!rawText.trim()} onClick={analyze}>
            Phân tích
          </button>
        </div>

        {result && (
          <div style={preview}>
            {result.warnings.map((warning, index) => (
              <div key={index} style={warningBox}>⚠ {warning}</div>
            ))}

            {result.candidates.length > 1 && (
              <div style={candidateGrid}>
                {result.candidates.map((candidate, index) => (
                  <button
                    key={`${candidate.room.room_code || 'room'}-${index}`}
                    type="button"
                    onClick={() => setSelected(index)}
                    style={{
                      ...candidateBtn,
                      ...(selected === index ? candidateBtnActive : {}),
                    }}
                  >
                    <strong>{candidate.room.room_code || `Phòng ${index + 1}`}</strong>
                    <span>{formatPrice(candidate.room.price)} đ</span>
                  </button>
                ))}
              </div>
            )}

            {selectedCandidate && (
              <div style={dataCard}>
                <PreviewRow label="Mã phòng" value={selectedCandidate.room.room_code} />
                <PreviewRow label="Loại phòng" value={result.sharedRoom.room_type} />
                <PreviewRow label="Số nhà" value={result.sharedRoom.house_number} />
                <PreviewRow label="Địa chỉ" value={result.sharedRoom.address} />
                <PreviewRow label="Phường" value={result.sharedRoom.ward} />
                <PreviewRow label="Quận" value={result.sharedRoom.district} />
                <PreviewRow label="Giá" value={selectedCandidate.room.price ? `${formatPrice(selectedCandidate.room.price)} đ` : ''} />
                <PreviewRow label="Điện" value={result.sharedDetail.electric_fee_value ? `${formatPrice(result.sharedDetail.electric_fee_value)} / ${result.sharedDetail.electric_fee_unit}` : ''} />
                <PreviewRow label="Nước" value={result.sharedDetail.water_fee_value ? `${formatPrice(result.sharedDetail.water_fee_value)} / ${result.sharedDetail.water_fee_unit}` : ''} />
                <PreviewRow label="Dịch vụ" value={result.sharedDetail.service_fee_value ? `${formatPrice(result.sharedDetail.service_fee_value)} / ${result.sharedDetail.service_fee_unit}` : ''} />
                <PreviewRow label="Giữ xe" value={result.sharedDetail.parking_fee_value ? `${formatPrice(result.sharedDetail.parking_fee_value)} / ${result.sharedDetail.parking_fee_unit}` : ''} />
                <PreviewRow label="Mô tả" value={selectedCandidate.room.description} multiline />
                <PreviewRow label="Chính sách" value={result.sharedRoom.chinh_sach} multiline />

                {selectedCandidate.warnings.map((warning, index) => (
                  <div key={index} style={warningBox}>⚠ {warning}</div>
                ))}
              </div>
            )}

            <div style={actions}>
              <button type="button" style={secondaryBtn} onClick={onClose}>Hủy</button>
              <button type="button" style={applyBtn} disabled={!selectedCandidate} onClick={apply}>
                Áp dụng vào form
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function PreviewRow({
  label,
  value,
  multiline = false,
}: {
  label: string
  value: unknown
  multiline?: boolean
}) {
  const text = String(value ?? '').trim()
  return (
    <div style={row}>
      <div style={rowLabel}>{label}</div>
      <div style={{ ...rowValue, whiteSpace: multiline ? 'pre-wrap' : 'normal' }}>
        {text || <span style={{ color: '#9ca3af' }}>Chưa nhận diện</span>}
      </div>
    </div>
  )
}

const overlay: CSSProperties = {
  position: 'fixed',
  inset: 0,
  zIndex: 10050,
  background: 'rgba(15, 23, 42, 0.55)',
  display: 'flex',
  alignItems: 'flex-start',
  justifyContent: 'center',
  padding: 16,
  overflowY: 'auto',
}

const box: CSSProperties = {
  width: '100%',
  maxWidth: 760,
  marginTop: 28,
  marginBottom: 28,
  background: '#fff',
  borderRadius: 16,
  boxShadow: '0 24px 80px rgba(15, 23, 42, 0.28)',
  padding: 20,
}

const header: CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'flex-start',
  gap: 16,
  marginBottom: 14,
}

const title: CSSProperties = { fontSize: 22, fontWeight: 800, color: '#111827' }
const subTitle: CSSProperties = { fontSize: 13, color: '#6b7280', marginTop: 4 }
const closeBtn: CSSProperties = {
  border: 0,
  background: '#f3f4f6',
  width: 36,
  height: 36,
  borderRadius: 10,
  fontSize: 24,
  cursor: 'pointer',
}
const textarea: CSSProperties = {
  width: '100%',
  minHeight: 220,
  resize: 'vertical',
  border: '1px solid #d1d5db',
  borderRadius: 12,
  padding: 14,
  fontSize: 14,
  lineHeight: 1.55,
  outline: 'none',
  boxSizing: 'border-box',
}
const actions: CSSProperties = {
  display: 'flex',
  justifyContent: 'flex-end',
  gap: 10,
  marginTop: 14,
}
const secondaryBtn: CSSProperties = {
  border: '1px solid #d1d5db',
  background: '#fff',
  color: '#111827',
  padding: '10px 16px',
  borderRadius: 10,
  cursor: 'pointer',
  fontWeight: 600,
}
const analyzeBtn: CSSProperties = {
  border: 0,
  background: '#111827',
  color: '#fff',
  padding: '10px 16px',
  borderRadius: 10,
  cursor: 'pointer',
  fontWeight: 700,
}
const applyBtn: CSSProperties = {
  border: 0,
  background: '#2563eb',
  color: '#fff',
  padding: '10px 16px',
  borderRadius: 10,
  cursor: 'pointer',
  fontWeight: 700,
}
const preview: CSSProperties = { marginTop: 18 }
const warningBox: CSSProperties = {
  background: '#fff7ed',
  border: '1px solid #fdba74',
  color: '#9a3412',
  borderRadius: 10,
  padding: '9px 11px',
  fontSize: 13,
  marginBottom: 10,
}
const candidateGrid: CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: 8,
  marginBottom: 12,
}
const candidateBtn: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 3,
  border: '1px solid #d1d5db',
  background: '#fff',
  borderRadius: 10,
  padding: '9px 12px',
  cursor: 'pointer',
  color: '#111827',
}
const candidateBtnActive: CSSProperties = {
  borderColor: '#2563eb',
  background: '#eff6ff',
  color: '#1d4ed8',
}
const dataCard: CSSProperties = {
  border: '1px solid #e5e7eb',
  borderRadius: 12,
  overflow: 'hidden',
}
const row: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '150px minmax(0, 1fr)',
  borderBottom: '1px solid #f3f4f6',
}
const rowLabel: CSSProperties = {
  padding: '10px 12px',
  background: '#f9fafb',
  fontSize: 13,
  fontWeight: 700,
  color: '#374151',
}
const rowValue: CSSProperties = {
  padding: '10px 12px',
  fontSize: 13,
  color: '#111827',
  overflowWrap: 'anywhere',
}
