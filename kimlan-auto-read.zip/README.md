# Cài tính năng Auto read cho modal Thêm phòng

## Cách nhanh nhất

Giải nén thư mục này, mở PowerShell tại thư mục vừa giải nén và chạy:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\apply-auto-read.ps1 -ProjectRoot "C:\Users\Admin\Desktop\KimLan.group"
```

Sau đó chạy:

```powershell
cd C:\Users\Admin\Desktop\KimLan.group
npm run build
npm run dev
```

## File được tạo/sửa

- Tạo: `app/admin/RoomModal/AutoReadModal.tsx`
- Sửa tự động: `app/admin/RoomModal/index.tsx`

## Cách hoạt động

- Nút `Auto read` chỉ hiện khi thêm phòng mới.
- Admin dán form tin nhắn.
- Bấm `Phân tích`.
- Nếu có nhiều phòng, chọn đúng mã phòng.
- Bấm `Áp dụng vào form`.
- Hệ thống chỉ điền field nhận diện được, giữ nguyên media hiện tại và không tự lưu.
