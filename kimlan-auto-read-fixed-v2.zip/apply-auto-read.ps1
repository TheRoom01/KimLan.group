﻿param(
  [string]$ProjectRoot = "C:\Users\Admin\Desktop\KimLan.group"
)

$ErrorActionPreference = "Stop"

$roomModalPath = Join-Path $ProjectRoot "app\admin\RoomModal\index.tsx"
$autoReadPath = Join-Path $ProjectRoot "app\admin\RoomModal\AutoReadModal.tsx"
$templatePath = Join-Path $PSScriptRoot "app\admin\RoomModal\AutoReadModal.tsx"

if (!(Test-Path $roomModalPath)) {
  throw "RoomModal index.tsx not found: $roomModalPath"
}

if (!(Test-Path $templatePath)) {
  throw "AutoReadModal template not found: $templatePath"
}

New-Item -ItemType Directory -Force -Path (Split-Path $autoReadPath) | Out-Null

$resolvedTemplate = [System.IO.Path]::GetFullPath($templatePath)
$resolvedTarget = [System.IO.Path]::GetFullPath($autoReadPath)

if ($resolvedTemplate -ne $resolvedTarget) {
  Copy-Item -Force $templatePath $autoReadPath
} else {
  Write-Host "Skip copying AutoReadModal.tsx because source and target are identical." -ForegroundColor Yellow
}

$content = Get-Content -Raw -Encoding UTF8 $roomModalPath

# 1) Import
if ($content -notmatch "import\s+AutoReadModal") {
  $pattern = "import\s+RoomAmenityTab\s+from\s+['""]\./RoomAmenityTab['""]"
  if ($content -notmatch $pattern) {
    throw "Cannot find RoomAmenityTab import."
  }

  $content = [regex]::Replace(
    $content,
    $pattern,
    { param($m) $m.Value + "`r`nimport AutoReadModal, { type AutoReadCandidate } from './AutoReadModal'" },
    1
  )
}

# 2) State
if ($content -notmatch "const\s+\[showAutoRead,\s*setShowAutoRead\]") {
  $pattern = "const\s+\[showCloseConfirm,\s*setShowCloseConfirm\]\s*=\s*useState\(false\)"
  if ($content -notmatch $pattern) {
    throw "Cannot find showCloseConfirm state."
  }

  $content = [regex]::Replace(
    $content,
    $pattern,
    { param($m) $m.Value + "`r`nconst [showAutoRead, setShowAutoRead] = useState(false)" },
    1
  )
}

# 3) Apply handler: insert directly before "if (!open) return null"
if ($content -notmatch "const\s+applyAutoReadCandidate\s*=") {
  $pattern = "(?m)^\s*if\s*\(\s*!open\s*\)\s*return\s+null\s*$"
  if ($content -notmatch $pattern) {
    throw "Cannot find 'if (!open) return null'."
  }

  $handler = @'
const applyAutoReadCandidate = (
  candidate: AutoReadCandidate,
  shared: {
    room: Partial<RoomForm>
    detail: Partial<RoomDetail>
  }
) => {
  const nextRoom = { ...shared.room, ...candidate.room }
  const nextDetail = { ...shared.detail, ...candidate.detail }

  setRoomForm((prev) => ({
    ...prev,
    ...Object.fromEntries(
      Object.entries(nextRoom).filter(([, value]) => {
        if (typeof value === 'number') return Number.isFinite(value) && value > 0
        if (typeof value === 'boolean') return true
        return String(value ?? '').trim() !== ''
      })
    ),
    media: prev.media,
  } as RoomForm))

  setDetailForm((prev) => ({
    ...prev,
    ...Object.fromEntries(
      Object.entries(nextDetail).filter(([, value]) => {
        if (typeof value === 'number') return Number.isFinite(value) && value > 0
        if (typeof value === 'boolean') return true
        return String(value ?? '').trim() !== ''
      })
    ),
  } as RoomDetail))

  setFeeAutofillDone(true)
  setActiveTab('info')
  onNotify?.('Auto read đã điền dữ liệu vào form. Vui lòng kiểm tra lại trước khi lưu.')
}

'@

  $content = [regex]::Replace(
    $content,
    $pattern,
    { param($m) $handler + $m.Value },
    1
  )
}

# 4) Header button
if ($content -notmatch ">\s*Auto read\s*</button>") {
  $pattern = "<h3>\{isPending\s*\?\s*'Chỉnh sửa import Zalo'\s*:\s*isEdit\s*\?\s*'Chỉnh sửa phòng'\s*:\s*'Thêm phòng mới'\}</h3>"
  if ($content -notmatch $pattern) {
    throw "Cannot find modal title h3."
  }

  $newHeader = @'
<div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
  <h3 style={{ margin: 0 }}>
    {isPending ? 'Chỉnh sửa import Zalo' : isEdit ? 'Chỉnh sửa phòng' : 'Thêm phòng mới'}
  </h3>

  {!isPending && !isEdit && !isClone && (
    <button
      type="button"
      onClick={() => setShowAutoRead(true)}
      style={{
        border: '1px solid #2563eb',
        background: '#eff6ff',
        color: '#1d4ed8',
        padding: '9px 14px',
        borderRadius: 10,
        cursor: 'pointer',
        fontWeight: 700,
      }}
    >
      Auto read
    </button>
  )}
</div>
'@

  $content = [regex]::Replace(
    $content,
    $pattern,
    [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $newHeader },
    1
  )
}

# 5) Render nested modal before close confirmation
if ($content -notmatch "<AutoReadModal") {
  $pattern = "(?m)^\s*\{showCloseConfirm\s*&&\s*\($"
  if ($content -notmatch $pattern) {
    throw "Cannot find showCloseConfirm render block."
  }

  $render = @'
      <AutoReadModal
        open={showAutoRead}
        onClose={() => setShowAutoRead(false)}
        onApply={applyAutoReadCandidate}
      />

'@

  $content = [regex]::Replace(
    $content,
    $pattern,
    { param($m) $render + $m.Value },
    1
  )
}

Set-Content -Path $roomModalPath -Value $content -Encoding UTF8

Write-Host ""
Write-Host "Auto read patch completed." -ForegroundColor Green
Write-Host "Updated: $roomModalPath"
Write-Host "Component: $autoReadPath"
Write-Host ""
Write-Host "Next command:" -ForegroundColor Cyan
Write-Host "npm run build"
